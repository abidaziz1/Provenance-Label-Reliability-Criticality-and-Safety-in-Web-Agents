# Backlog of ideas

Parked ideas. None is built unless roadmap task N0.4 promotes it and Alam approves. Source for items E1 to E8: the external review of 25 Sep 2026 (`docs/reviews/2026-09-25_external_review.md`). The "Initial read" column is the handoff assessment; N0.4 replaces it with a decision.

| ID | Idea | Initial read | Condition to promote | Links to | Decision (N0.4) |
| --- | --- | --- | --- | --- | --- |
| E1 | Confinement Width metric, CW = f(A, O, G) | Worth doing only as a definition computed from measured quantities, for example the share of actionable elements an untrusted-influenced decision can reach under a given gate. The review's example scores (1.0, 0.5, 0.2, 0.1) were never measured and must not appear anywhere. | A definition that a reader can compute for Prismata and UCM from their papers or code, and that predicts effect on our gate-width curve better than label accuracy does | C4, C5, task 3.6 | |
| E2 | Risk = LabelError x GateWidth x ActionImpact | The four-layer factorization (C5) is the exact version: a product of conditional probabilities. A product with a raw width as a factor is not a probability and would draw a reviewer's fire. Merge into C5; do not add a second formula. | none: merge | C5 | |
| E3 | Failure taxonomy, four types | Useful as a table that organizes arms we already measured: label error with no admission (exposure only), admission with no label error (influence escape, 43.4% page-wide), both, neither. Add a type only with a measured instance. | Every type has a measured rate from a committed result | C3, C4 | |
| E4 | Beyond web agents: MCP, RAG, coding agents | Scope growth with no evidence behind it. At most a discussion paragraph on how width applies elsewhere. Keep separate from Alam's other projects. | Gate 2 passes early and a reviewer asks | discussion section | |
| E5 | Adaptive verification | Already planned as C9, tasks 4.1 and 4.2, TDSC route only. | Venue call on Dec 13 | C9 | |
| E6 | Cost-security frontier | Cheap on the TMLR route: tokens per page at each gate width against the gate-width curve, from data we have. A full frontier needs the Phase 4 mechanism. | Free version in 3.6; full version only with Phase 4 | C4, C9, task 3.6 | |
| E7 | Stronger baselines: no defense, oracle defense, random gate | Adopt now. No defense (`P_none`) and the oracle gate exist; a random gate of matched width is the missing control that separates width from which elements are admitted. Add it to the pre-registration (1.6) and to 3.6. | none: adopt | C4, tasks 1.6, 3.6 | |
| E8 | TrustBoundaryBench | A benchmark paper needs broad coverage and a maintained artifact. The artifact from 5.4 could be packaged as one later. | Reviewers ask for it, or after acceptance | task 5.4 | |
| E9 | Title "Confinement Width: A Security Principle for Trust Boundaries in Autonomous AI Agents" | "Principle" invites a KNOWN verdict (Lampson 1973; Saltzer and Schroeder 1975). Pick the title after Gate N. | Gate N | N0.5 | |
| E10 | "Do not add more models, attacks or another detector" | Agrees with the roadmap. Keep. | none | whole plan | |

## Other ideas

Add rows here as they come up: date, source, idea, initial read. Never start work from this file.
